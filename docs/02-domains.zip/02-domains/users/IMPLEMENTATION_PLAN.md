# Users v1 Implementation Plan

**Status:** PLANNED  
**Scope:** Incremental delivery of Users v1 — Assisted Customer Onboarding.  
**Authority:** Owns delivery slices and dependencies, not product rules.  
**Last reviewed:** 2026-07-12  
**Related:** `DOMAIN.md`, `INTEGRATION_CONTRACT.md`, `VALIDATION_CHECKLIST.md`.

| Slice | Scope | Status | Dependency / exit |
| --- | --- | --- | --- |
| A — Directory and Overview | Tenant directory, cursor loading, summary, All/Invitations, search, selection, minimal Overview, states/responsive/a11y | PLANNED | Contract verifies read projection/authorization |
| B — Assisted Invitation Creation | Name/email/language, optional phone/address, proposal persistence, localized delivery and outcomes | PLANNED | Contract verifies command, locale, delivery outcome/identity |
| C — Customer Acceptance and Profile Review | Identity path, access acceptance, opaque proposal retrieval, review/save, conflict choice, resume guidance | PLANNED | Requires ownership/location decisions; readiness completion depends on Service Requests |
| D — Invitation Lifecycle Recovery | Resend, renew-and-resend, delivery recovery, revoke | PLANNED | Requires expiry/token/cooldown/history/authorization contract |
| E — Service Request Readiness Integration | Derived readiness, CTA, shared validation and Service Requests hard-gate integration point | PLANNED | Requires Service Requests contract |

Slices may validate independently. Users v1 is not complete until A–E deliver
and end-to-end validation passes. Do not bundle deferred active/attention, CRM,
Requests inspector content, accepted-user administration, sorting or page size.

